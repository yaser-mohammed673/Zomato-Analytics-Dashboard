-- ============================
-- QUESTION 3
-- Convert Average Cost for Two into USD
-- ============================
-- <your Q3 code here> -- 

SELECT 
    m.RestaurantID,
    m.RestaurantName,
    m.Currency,
    m.Average_Cost_for_two,
    c.USD_Rate,
    
    ROUND(m.Average_Cost_for_two * c.USD_Rate, 2) AS Cost_in_USD

FROM main m
JOIN currency c 
    ON m.Currency = c.Currency;
    DESCRIBE currency;
    
    
    select distinct Currency from main;
    
    select distinct Currency FROM currency;
    
    SELECT 
    m.RestaurantID,
    m.RestaurantName,
    m.Currency,
    m.Average_Cost_for_two,
    c.USD_Rate,
    ROUND(m.Average_Cost_for_two * c.USD_Rate, 2) AS Cost_in_USD
FROM main m
JOIN currency c 
    ON m.Currency = c.Currency;
