-- ============================
-- QUESTION 1
-- Table Structure & Keys
-- ============================
 -- <your Q1 code here> --

describe main;
ALTER TABLE main 
  modify RestaurantID INT NOT NULL;
  ALTER TABLE main
  ADD primary key(RestaurantID);
    -- 
    ALTER TABLE country
MODIFY CountryID INT NOT NULL;

ALTER TABLE country
ADD PRIMARY KEY (CountryID);

ALTER TABLE currency
MODIFY Currency VARCHAR(50) NOT NULL;

ALTER TABLE currency
ADD PRIMARY KEY (Currency);

ALTER TABLE main
MODIFY CountryCode INT;

ALTER TABLE main
ADD CONSTRAINT fk_country
FOREIGN KEY (CountryCode)
REFERENCES country(CountryID);

ALTER TABLE main
MODIFY Currency VARCHAR(50);

ALTER TABLE main
ADD CONSTRAINT fk_currency
FOREIGN KEY (Currency)
REFERENCES currency(Currency);
-----------------------------
USE zomato_project;

-- =========================
-- FIX MAIN TABLE
-- =========================

ALTER TABLE main 
MODIFY RestaurantID INT NOT NULL;

ALTER TABLE main 
MODIFY CountryCode INT;

ALTER TABLE main 
MODIFY Currency VARCHAR(50);

ALTER TABLE main 
ADD PRIMARY KEY (RestaurantID);


-- =========================
-- FIX COUNTRY TABLE
-- =========================

ALTER TABLE country 
MODIFY CountryID INT NOT NULL;

ALTER TABLE country 
ADD PRIMARY KEY (CountryID);


-- =========================
-- FIX CURRENCY TABLE
-- =========================

ALTER TABLE currency 
MODIFY Currency VARCHAR(50) NOT NULL;

ALTER TABLE currency 
ADD PRIMARY KEY (Currency);


-- =========================
-- ADD FOREIGN KEYS
-- =========================

ALTER TABLE main
ADD CONSTRAINT fk_country
FOREIGN KEY (CountryCode)
REFERENCES country(CountryID);

ALTER TABLE main
ADD CONSTRAINT fk_currency
FOREIGN KEY (Currency)
REFERENCES currency(Currency);


-- =========================
-- VERIFY STRUCTURE
-- =========================

SHOW CREATE TABLE main;