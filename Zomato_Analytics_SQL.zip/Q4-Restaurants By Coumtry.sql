-- ============================
-- QUESTION 4
-- Numbers of Resturants based on City and Country
-- ============================
-- <your Q4 code here> --


SELECT 
    c.Countryname,
    COUNT(m.RestaurantID) AS Total_Restaurants
FROM main m
JOIN country c
    ON m.CountryCode = c.CountryID
GROUP BY c.Countryname
ORDER BY Total_Restaurants DESC;