create database project;
use project;
select * from main_data;
select* from country;
select * from currency;
select * from calendar;

select count(*) from main_data;

                                               #Q6 Count of Resturants based on Average Ratings ###

SELECT Rating, count(Rating) AS Total_Restaurants
FROM main_data
GROUP BY Rating
ORDER BY Rating DESC;

                             #Q7 Create buckets based on Average Price of reasonable size and find out how many resturants falls in each buckets ###
SELECT 
CASE 
	    WHEN Average_Cost_for_two < 500 THEN 'Low'
        WHEN Average_Cost_for_two BETWEEN 500 AND 1500 THEN 'Medium'
        WHEN Average_Cost_for_two BETWEEN 1501 AND 3000 THEN 'High'
        ELSE 'Luxury'
    END AS Price_Category,
    COUNT(*) AS Total_Restaurants
FROM main_data
GROUP BY 
    CASE 
        WHEN Average_Cost_for_two < 500 THEN 'Low'
        WHEN Average_Cost_for_two BETWEEN 500 AND 1500 THEN 'Medium'
        WHEN Average_Cost_for_two BETWEEN 1501 AND 3000 THEN 'High'
        ELSE 'Luxury'
    END
ORDER BY Total_Restaurants;


                                                           #Q8 Percentage of Resturants based on "Has_Table_booking" ###
                                                           
SELECT Has_Table_booking, COUNT(*)/ (SELECT COUNT(*) FROM main_data)* 100 AS Percentage
FROM main_data
GROUP BY Has_Table_booking;

                                                             #Q9 Percentage of Resturants based on "Has_Online_delivery" ###

SELECT Has_Online_delivery, count(*)/ (SELECT COUNT(*) FROM main_data)* 100 AS Percentage
FROM main_data
GROUP BY Has_Online_delivery;
