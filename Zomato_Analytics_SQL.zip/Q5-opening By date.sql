-- ============================
-- QUESTION 5
-- Resturants opening based on Year , Quarter , Month
-- ============================
-- <your Q5 code here> -- 

describe main;

alter table main
add column Datekey INT;

SET SQL_SAFE_UPDATES = 0;

update main 
set Datekey =
(Year_Opening * 10000 +
 Month_Opening * 100 +
 Day_Opening);
 
 SELECT
    d.Year,
    d.Quarter,
    d.MonthName,
    COUNT(m.RestaurantID) AS Total_Restaurants
FROM main m
JOIN date_dim d
ON m.DateKey = d.DateKey
GROUP BY
    d.Year,
    d.Quarter,
    d.MonthName
ORDER BY
    d.Year,
    d.Quarter,
    d.MonthName;















