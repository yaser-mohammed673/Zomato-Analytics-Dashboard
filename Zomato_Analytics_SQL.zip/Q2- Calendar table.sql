-- ============================
-- QUESTION 2
-- Calendar Table Creation
-- ============================
--  <your Q2 code here> --

USE zomato_project;

DROP TABLE IF EXISTS date_dim;

CREATE TABLE date_dim (
    DateKey INT PRIMARY KEY,
    FullDate DATE,
    Year INT,
    MonthNo INT,
    MonthName VARCHAR(20),
    Quarter VARCHAR(5),
    YearMonth VARCHAR(10),
    WeekdayNo INT,
    WeekdayName VARCHAR(20),
    FinancialMonth INT,
    FinancialQuarter VARCHAR(5)
);

INSERT INTO date_dim
SELECT DISTINCT
    (Year_Opening * 10000 + Month_Opening * 100 + Day_Opening) AS DateKey,
    STR_TO_DATE(CONCAT(Year_Opening,'-',Month_Opening,'-',Day_Opening), '%Y-%m-%d') AS FullDate,
    Year_Opening AS Year,
    Month_Opening AS MonthNo,
    MONTHNAME(STR_TO_DATE(CONCAT(Year_Opening,'-',Month_Opening,'-',Day_Opening), '%Y-%m-%d')) AS MonthName,
    CONCAT('Q', QUARTER(STR_TO_DATE(CONCAT(Year_Opening,'-',Month_Opening,'-',Day_Opening), '%Y-%m-%d'))) AS Quarter,
    DATE_FORMAT(STR_TO_DATE(CONCAT(Year_Opening,'-',Month_Opening,'-',Day_Opening), '%Y-%m-%d'), '%Y-%b') AS YearMonth,
    WEEKDAY(STR_TO_DATE(CONCAT(Year_Opening,'-',Month_Opening,'-',Day_Opening), '%Y-%m-%d')) + 1 AS WeekdayNo,
    DAYNAME(STR_TO_DATE(CONCAT(Year_Opening,'-',Month_Opening,'-',Day_Opening), '%Y-%m-%d')) AS WeekdayName,

    -- Financial Month (April = 1)
    CASE 
        WHEN Month_Opening >= 4 THEN Month_Opening - 3
        ELSE Month_Opening + 9
    END AS FinancialMonth,

    -- Financial Quarter
    CASE
        WHEN Month_Opening BETWEEN 4 AND 6 THEN 'FQ1'
        WHEN Month_Opening BETWEEN 7 AND 9 THEN 'FQ2'
        WHEN Month_Opening BETWEEN 10 AND 12 THEN 'FQ3'
        ELSE 'FQ4'
    END AS FinancialQuarter

FROM main;

SELECT * FROM date_dim limit 10;

ALTER TABLE main
ADD COLUMN DateKey INT;

UPDATE main
SET DateKey = (Year_Opening * 10000 + Month_Opening * 100 + Day_Opening);

ALTER TABLE main
ADD CONSTRAINT fk_date
FOREIGN KEY (DateKey)
REFERENCES date_dim(DateKey);

SELECT * FROM date_dim limit 10;